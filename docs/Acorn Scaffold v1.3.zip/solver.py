# You may need this if you really want to use a recursive solution!
# It raises the cap on how many recursions can happen. Use this at your own risk!

# sys.setrecursionlimit(100000)


def solve(mode):
    pass


if __name__ == "__main__":
    solution_found = False
    if solution_found:
        pass
        # Print your solution...
    else:
        print("There is no possible path.")
