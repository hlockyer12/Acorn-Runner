from game import Game
import os
import sys

# Your code...
