class Player:
    def __init__(self):
        self.display = 'A'
        self.num_water_buckets = 0
        self.row = ?
        self.col = ?

    def move(self, move):
        pass
